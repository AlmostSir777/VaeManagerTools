//
//  MessageViewController.h
//  Vae_ManagerTools
//
//  Created by 闵玉辉 on 2017/12/28.
//  Copyright © 2017年 闵玉辉. All rights reserved.
//

#import "VaeBaseViewController.h"

@interface MessageViewController : VaeBaseViewController
@property (nonatomic,assign) NSInteger currrentPage;
@end
