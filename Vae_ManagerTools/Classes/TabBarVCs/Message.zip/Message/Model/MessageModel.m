//
//  MessageModel.m
//  Vae_ManagerTools
//
//  Created by 闵玉辉 on 2018/4/9.
//  Copyright © 2018年 闵玉辉. All rights reserved.
//

#import "MessageModel.h"

@implementation MessageModel

@end
