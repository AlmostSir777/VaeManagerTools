//
//  HorizenButton.h
//  SmallStuff
//
//  Created by Hy on 2017/3/30.
//  Copyright © 2017年 yuhuimin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HorizenButton : UIButton

@property (nonatomic, assign) CGFloat margeWidth;
@property (nonatomic,assign) BOOL isTitleLeft;
@end
